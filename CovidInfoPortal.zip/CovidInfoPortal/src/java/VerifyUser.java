/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
public class VerifyUser extends HttpServlet {

    private Connection con; private PreparedStatement ps1;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
            PrintWriter out=response.getWriter();
            
            String id=request.getParameter("uid");
            String pw=request.getParameter("password");
            String utype=request.getParameter("utype");
            
            
            if(utype.equals("super-admin")){
                if(id.equals("sadmin")&& pw.equals("ssi")){
                     out.println("Welcome Super-Admin");
                }else{
                    out.println("INVAILD SUPER ADMIN ACCOUNT..");
                }
            }else if(utype.equals("state-admin")){
                out.println("Welcome State-Admin");
            }else if(utype.equals("end-user")){
                //out.println("Welcome End-User");
                //we need to autheticate from the Data-Base.
                try{
                    Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/coviddata","root","root");
                PreparedStatement ps1=con.prepareStatement("SELECT * FROM users where email=? AND password=?");
                    ps1.setString(1, id);
                    ps1.setString(2, pw);
                    ResultSet rs=ps1.executeQuery();
                    boolean found=rs.next();
                    if(found){
                        out.println("WELCOME END USER");
                    }else{
                        out.println("INVAILD END USER ACCOUNT..");
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
                
            }
            
            
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
